CREATE DATABASE IF NOT EXISTS `clinica-db`;

USE `clinica-db`;

DROP TABLE IF EXISTS `bitacora`;

CREATE TABLE `bitacora` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `recurso` varchar(50) DEFAULT NULL,
  `operacion` varchar(50) DEFAULT NULL,
  `host` varchar(50) DEFAULT NULL,
  `fecha` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=77 DEFAULT CHARSET=latin1;

INSERT INTO `bitacora` VALUES("6","1","ENTIDAD","ACTUALIZAR","localhost","2018-02-06 12:33:08");
INSERT INTO `bitacora` VALUES("7","1","ENTIDAD","DAR DE BAJA","localhost","2018-02-11 01:29:21");
INSERT INTO `bitacora` VALUES("8","1","ENTIDAD","DAR DE BAJA","localhost","2018-02-11 01:30:22");
INSERT INTO `bitacora` VALUES("9","1","DOCTORES","VIZUALIZAR DATOS","192.168.1.149","2018-03-16 21:09:04");
INSERT INTO `bitacora` VALUES("10","1","DOCTORES","ACTUALIZAR DATOS","192.168.1.149","2018-03-16 21:12:37");
INSERT INTO `bitacora` VALUES("11","1","SOLICITUD","VIZUALIZAR SOLICITUD","localhost","2018-03-16 21:16:41");
INSERT INTO `bitacora` VALUES("12","1","SOLICITUD","BUSCAR ESTADO DE SOLICITUD","localhost","2018-03-16 21:26:28");
INSERT INTO `bitacora` VALUES("13","1","SOLICITUD","BUSCAR ESTADO DE SOLICITUD","localhost","2018-03-16 21:26:31");
INSERT INTO `bitacora` VALUES("14","1","SOLICITUD","BUSCAR ESTADO DE SOLICITUD","localhost","2018-03-16 21:26:33");
INSERT INTO `bitacora` VALUES("15","1","SOLICITUD","BUSCAR ESTADO DE SOLICITUD","localhost","2018-03-16 21:26:36");
INSERT INTO `bitacora` VALUES("16","1","SOLICITUD","CAMBIAR ESTADO DE SOLICITUD","localhost","2018-03-16 21:26:37");
INSERT INTO `bitacora` VALUES("17","1","SOLICITUD","CAMBIAR ESTADO DE SOLICITUD","localhost","2018-03-16 21:26:54");
INSERT INTO `bitacora` VALUES("18","1","SOLICITUD","VIZUALIZAR SOLICITUD","localhost","2018-03-16 21:31:36");
INSERT INTO `bitacora` VALUES("19","1","SOLICITUD","VIZUALIZAR SOLICITUD","192.168.1.149","2018-03-16 21:37:13");
INSERT INTO `bitacora` VALUES("20","1","DOCTORES","VIZUALIZAR DATOS","192.168.1.210","2018-03-16 21:39:44");
INSERT INTO `bitacora` VALUES("21","1","SOLICITUD","VIZUALIZAR SOLICITUD","localhost","2018-03-16 21:40:10");
INSERT INTO `bitacora` VALUES("22","1","SOLICITUD","VIZUALIZAR SOLICITUD","localhost","2018-03-16 21:45:55");
INSERT INTO `bitacora` VALUES("23","1","PACIENTES","VIZUALIZAR DATOS DEL PACIENTE","192.168.1.149","2018-03-16 21:46:55");
INSERT INTO `bitacora` VALUES("24","1","SOLICITUD","AGREGAR UNA NUEVA SOLICITUD","192.168.1.149","2018-03-16 21:47:13");
INSERT INTO `bitacora` VALUES("25","1","SOLICITUD","AGREGAR UNA NUEVA SOLICITUD","192.168.1.149","2018-03-16 21:47:25");
INSERT INTO `bitacora` VALUES("26","1","SOLICITUD","VIZUALIZAR SOLICITUD","localhost","2018-03-16 21:47:34");
INSERT INTO `bitacora` VALUES("27","1","SOLICITUD","PRESENTAR LA INFORMACION DE UNA SOLICITUD","localhost","2018-03-16 21:47:49");
INSERT INTO `bitacora` VALUES("28","1","SOLICITUD","PRESENTAR LA INFORMACION DE UNA SOLICITUD","localhost","2018-03-16 21:47:50");
INSERT INTO `bitacora` VALUES("29","1","SOLICITUD","PRESENTAR LA INFORMACION DE UNA SOLICITUD","localhost","2018-03-16 21:47:56");
INSERT INTO `bitacora` VALUES("30","1","SOLICITUD","PRESENTAR LA INFORMACION DE UNA SOLICITUD","localhost","2018-03-16 21:47:57");
INSERT INTO `bitacora` VALUES("31","1","SOLICITUD","VIZUALIZAR SOLICITUD","192.168.1.149","2018-03-16 21:47:58");
INSERT INTO `bitacora` VALUES("32","1","SOLICITUD","PRESENTAR LA INFORMACION DE UNA SOLICITUD","localhost","2018-03-16 21:47:58");
INSERT INTO `bitacora` VALUES("33","1","SOLICITUD","PRESENTAR LA INFORMACION DE UNA SOLICITUD","localhost","2018-03-16 21:47:59");
INSERT INTO `bitacora` VALUES("34","1","SOLICITUD","PRESENTAR LA INFORMACION DE UNA SOLICITUD","192.168.1.149","2018-03-16 21:48:02");
INSERT INTO `bitacora` VALUES("35","1","SOLICITUD","PRESENTAR LA INFORMACION DE UNA SOLICITUD","192.168.1.149","2018-03-16 21:48:05");
INSERT INTO `bitacora` VALUES("36","1","SOLICITUD","PRESENTAR LA INFORMACION DE UNA SOLICITUD","localhost","2018-03-16 21:48:21");
INSERT INTO `bitacora` VALUES("37","1","SOLICITUD","PRESENTAR LA INFORMACION DE UNA SOLICITUD","localhost","2018-03-16 21:48:22");
INSERT INTO `bitacora` VALUES("38","1","SOLICITUD","AGREGAR CAMPO A LA SOLICITUD","192.168.1.149","2018-03-16 21:48:22");
INSERT INTO `bitacora` VALUES("39","1","SOLICITUD","AGREGAR RESPUESTA A LA SOLICITUD","192.168.1.149","2018-03-16 21:48:30");
INSERT INTO `bitacora` VALUES("40","1","SOLICITUD","CAMBIAR ESTADO EXAMEN","192.168.1.149","2018-03-16 21:48:33");
INSERT INTO `bitacora` VALUES("41","1","SOLICITUD","CAMBIAR ESTADO ITEM","192.168.1.149","2018-03-16 21:48:36");
INSERT INTO `bitacora` VALUES("42","1","SOLICITUD","CAMBIAR ESTADO DE SOLICITUD","192.168.1.149","2018-03-16 21:48:41");
INSERT INTO `bitacora` VALUES("43","1","SOLICITUD","AGREGAR UN CODIGO A LA FACTURA","192.168.1.149","2018-03-16 21:48:47");
INSERT INTO `bitacora` VALUES("44","1","SOLICITUD","FACTURAR UNA SOLICITUD","192.168.1.149","2018-03-16 21:48:51");
INSERT INTO `bitacora` VALUES("45","1","SOLICITUD","PRESENTAR LA INFORMACION DE UNA SOLICITUD","192.168.1.149","2018-03-16 21:48:57");
INSERT INTO `bitacora` VALUES("46","1","SOLICITUD","AGREGAR CAMPO A LA SOLICITUD","192.168.1.149","2018-03-16 21:49:00");
INSERT INTO `bitacora` VALUES("47","1","SOLICITUD","AGREGAR RESPUESTA A LA SOLICITUD","192.168.1.149","2018-03-16 21:49:21");
INSERT INTO `bitacora` VALUES("48","1","SOLICITUD","CAMBIAR ESTADO EXAMEN","192.168.1.149","2018-03-16 21:49:24");
INSERT INTO `bitacora` VALUES("49","1","SOLICITUD","CAMBIAR ESTADO ITEM","192.168.1.149","2018-03-16 21:49:27");
INSERT INTO `bitacora` VALUES("50","1","SOLICITUD","CAMBIAR ESTADO DE SOLICITUD","192.168.1.149","2018-03-16 21:49:34");
INSERT INTO `bitacora` VALUES("51","1","SOLICITUD","AGREGAR UN CODIGO A LA FACTURA","192.168.1.149","2018-03-16 21:49:39");
INSERT INTO `bitacora` VALUES("52","1","SOLICITUD","FACTURAR UNA SOLICITUD","192.168.1.149","2018-03-16 21:49:48");
INSERT INTO `bitacora` VALUES("53","1","SOLICITUD","VIZUALIZAR SOLICITUD","192.168.1.149","2018-03-16 21:50:46");
INSERT INTO `bitacora` VALUES("54","1","SOLICITUD","PRESENTAR LA INFORMACION DE UNA SOLICITUD","192.168.1.149","2018-03-16 21:50:46");
INSERT INTO `bitacora` VALUES("55","1","SOLICITUD","PRESENTAR LA INFORMACION DE UNA SOLICITUD","192.168.1.149","2018-03-16 21:52:16");
INSERT INTO `bitacora` VALUES("56","1","SOLICITUD","PRESENTAR LA INFORMACION DE UNA SOLICITUD","192.168.1.149","2018-03-16 21:52:19");
INSERT INTO `bitacora` VALUES("57","1","SOLICITUD","PRESENTAR LA INFORMACION DE UNA SOLICITUD","192.168.1.149","2018-03-16 21:52:21");
INSERT INTO `bitacora` VALUES("58","1","SOLICITUD","PRESENTAR LA INFORMACION DE UNA SOLICITUD","192.168.1.149","2018-03-16 21:52:23");
INSERT INTO `bitacora` VALUES("59","1","SOLICITUD","VIZUALIZAR SOLICITUD","localhost","2018-03-16 22:18:45");
INSERT INTO `bitacora` VALUES("60","1","SOLICITUD","PRESENTAR LA INFORMACION DE UNA SOLICITUD","localhost","2018-03-16 22:18:46");
INSERT INTO `bitacora` VALUES("61","1","SOLICITUD","VIZUALIZAR SOLICITUD","localhost","2018-03-16 22:18:47");
INSERT INTO `bitacora` VALUES("62","1","SOLICITUD","PRESENTAR LA INFORMACION DE UNA SOLICITUD","localhost","2018-03-16 22:18:48");
INSERT INTO `bitacora` VALUES("63","1","COMPRAS","PRESENTAR LOS DATOS DE LA COMPRAS","localhost","2018-03-16 22:28:06");
INSERT INTO `bitacora` VALUES("64","1","SUCURSALES","CAMBIAR ESTADO DE SUCURSAL","localhost","2018-03-16 22:28:16");
INSERT INTO `bitacora` VALUES("65","1","COMPRAS","PRESENTAR LOS DATOS DE LA COMPRAS","localhost","2018-03-16 22:28:18");
INSERT INTO `bitacora` VALUES("66","1","COMPRAS","PRESENTAR LOS DATOS DE UNA COMPRA","localhost","2018-03-16 22:28:21");
INSERT INTO `bitacora` VALUES("67","1","COMPRAS","PRESENTAR LOS ITEMS DE LA COMPRA","localhost","2018-03-16 22:28:22");
INSERT INTO `bitacora` VALUES("68","1","COMPRAS","PRESENTAR LOS DATOS DE LA COMPRAS","localhost","2018-03-16 22:28:24");
INSERT INTO `bitacora` VALUES("69","1","COMPRAS","PRESENTAR LOS DATOS DE LA COMPRAS","localhost","2018-03-16 22:30:45");
INSERT INTO `bitacora` VALUES("70","1","INVENTARIO","VIZUALIZAR EL INVENTARIO","localhost","2018-03-16 22:33:43");
INSERT INTO `bitacora` VALUES("71","1","INVENTARIO","VIZUALIZAR EL INVENTARIO","localhost","2018-03-16 22:34:40");
INSERT INTO `bitacora` VALUES("72","1","SOLICITUD","VIZUALIZAR SOLICITUD","localhost","2018-03-16 22:47:02");
INSERT INTO `bitacora` VALUES("73","1","SUCURSALES","CAMBIAR ESTADO DE SUCURSAL","localhost","2018-03-16 22:48:11");
INSERT INTO `bitacora` VALUES("74","1","SOLICITUD","VIZUALIZAR SOLICITUD","localhost","2018-03-16 22:48:14");
INSERT INTO `bitacora` VALUES("75","1","SOLICITUD","VIZUALIZAR SOLICITUD","localhost","2018-03-16 23:21:46");
INSERT INTO `bitacora` VALUES("76","1","SOLICITUD","VIZUALIZAR SOLICITUD","localhost","2018-03-16 23:23:08");



DROP TABLE IF EXISTS `catalogo_campos`;

CREATE TABLE `catalogo_campos` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_tipo_catalogo` int(11) DEFAULT NULL,
  `grupo_seleccion` int(11) DEFAULT NULL,
  `valor_opcional` tinyint(1) DEFAULT '1',
  `rango_valor` varchar(20) DEFAULT NULL,
  `unidades` varchar(20) DEFAULT NULL,
  `nombre_campo` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=57 DEFAULT CHARSET=latin1 AVG_ROW_LENGTH=292;

INSERT INTO `catalogo_campos` VALUES("1","2",NULL,"1","135-155","mmol/l","SODIO");
INSERT INTO `catalogo_campos` VALUES("2","1","2","1",NULL,"mg/dl","AMIKACINA");
INSERT INTO `catalogo_campos` VALUES("3","1","1","1",NULL,"mg","AMOXI+ÁCIDO CLAVULANICO");
INSERT INTO `catalogo_campos` VALUES("4","3",NULL,"1",NULL,"x campo","LEUCOCITOS");
INSERT INTO `catalogo_campos` VALUES("5","3",NULL,"1",NULL,"%","PORCENTAJE");
INSERT INTO `catalogo_campos` VALUES("6","1","1","1",NULL,"mg/ml","AMOXICILINA");
INSERT INTO `catalogo_campos` VALUES("7","1","1","0",NULL,"mg/ml","AMPICILINA");
INSERT INTO `catalogo_campos` VALUES("8","1","1","0",NULL,"mg/ml","AZITROMICINA");
INSERT INTO `catalogo_campos` VALUES("9","1","1","0",NULL,"mg/ml","CEFADROXILO");
INSERT INTO `catalogo_campos` VALUES("10","1","1","0",NULL,"mg/ml","CEFIXIMA");
INSERT INTO `catalogo_campos` VALUES("11","1","1","0",NULL,"mg/ml","CEFTRIAXONA");
INSERT INTO `catalogo_campos` VALUES("12","1","1","0",NULL,"mg/ml","CLARITROMICINA");
INSERT INTO `catalogo_campos` VALUES("13","1","1","0",NULL,"mg/ml","CIPROFLOXACINA");
INSERT INTO `catalogo_campos` VALUES("14","1","1","0",NULL,"mg/ml","DICLOXACILINA");
INSERT INTO `catalogo_campos` VALUES("15","1","1","0",NULL,"ml/ug","CLINDAMICINA");
INSERT INTO `catalogo_campos` VALUES("16","1","1","0",NULL,"mg/ml","FOSFOCIL");
INSERT INTO `catalogo_campos` VALUES("17","1","1","0",NULL,"mg/ml","CEFOXITIN");
INSERT INTO `catalogo_campos` VALUES("18","1","1","0",NULL,"mg/ml","KANAMICINA");
INSERT INTO `catalogo_campos` VALUES("19","1","1","0",NULL,"ml/ug","LEVOFLOXACINA");
INSERT INTO `catalogo_campos` VALUES("20","1","1","0",NULL,"ml/ug","LOMEFLOXACINA");
INSERT INTO `catalogo_campos` VALUES("21","1","1","0",NULL,"ml/ug","NITROFURANTORINA");
INSERT INTO `catalogo_campos` VALUES("22","1","1","0",NULL,"mg/ml","NORFLOXACINA");
INSERT INTO `catalogo_campos` VALUES("23","1","1","0",NULL,"ml/ug","OFLOXACINA");
INSERT INTO `catalogo_campos` VALUES("24","1","1","0",NULL,"mg/ml","PENICILINA");
INSERT INTO `catalogo_campos` VALUES("25","1","1","0",NULL,"mg/ml","TRIMETROPIN SULFA");
INSERT INTO `catalogo_campos` VALUES("26","1","2","0",NULL,"-","MUCUS");
INSERT INTO `catalogo_campos` VALUES("27","2",NULL,"1","60 - 110","mg/dl","GLUCOSA");
INSERT INTO `catalogo_campos` VALUES("28","2",NULL,"1","-","mg/ml","GLUCOSA POST-PANDRIAL");
INSERT INTO `catalogo_campos` VALUES("29","2",NULL,"1","Hasta 200","mg/dl","COLESTEROL");
INSERT INTO `catalogo_campos` VALUES("30","2",NULL,"1","70 - 170","mg/dl","TRIGLICERIDOS");
INSERT INTO `catalogo_campos` VALUES("31","2",NULL,"1","3.0 - 7.0","mg/dl","ÁCIDO URICO");
INSERT INTO `catalogo_campos` VALUES("32","2",NULL,"1","Hasta 1.1","mg/dl","CREATININA");
INSERT INTO `catalogo_campos` VALUES("33","2",NULL,"1","7.0 - 20.0","mg/dl","NITRÓGENO UREICO");
INSERT INTO `catalogo_campos` VALUES("34","2",NULL,"1","Hasta 37.0","U/L","TRANSAMINASA TGO");
INSERT INTO `catalogo_campos` VALUES("35","2",NULL,"1","Hasta 42.0","U/L","TRANSAMINASA TGP");
INSERT INTO `catalogo_campos` VALUES("36","2",NULL,"1","Hasta 1.2","mg/dl","BILIRUBINA TOTAL");
INSERT INTO `catalogo_campos` VALUES("37","2",NULL,"1","Hasta 0.25","mg/dl","BILIRUBINA DIRECTA");
INSERT INTO `catalogo_campos` VALUES("38","2",NULL,"1","8.1 - 10.4","mg/dl","CALCIO");
INSERT INTO `catalogo_campos` VALUES("39","2",NULL,"1","3.6 - 5.5","mmol/l","POTASIO");
INSERT INTO `catalogo_campos` VALUES("40","2",NULL,"1","36.0 - 50.0","%","HEMATÓCRITO");
INSERT INTO `catalogo_campos` VALUES("41","2",NULL,"1","12.0 - 16.0","gr.%","HEMOGLOBINA");
INSERT INTO `catalogo_campos` VALUES("42","2",NULL,"1","4.0 - 5.8","xmmc","GLÓBULOS ROJOS");
INSERT INTO `catalogo_campos` VALUES("43","2",NULL,"1","5.0 - 10.0","xmmc","GLÓBULOS BLANCOS");
INSERT INTO `catalogo_campos` VALUES("44","2",NULL,"1","80.0 - 99.0","xmmc","(VGM)");
INSERT INTO `catalogo_campos` VALUES("45","2",NULL,"1","26.5 - 33.5","xmmc","(CHbGM)");
INSERT INTO `catalogo_campos` VALUES("46","2",NULL,"1","32.0 - 36.0","Mic Cub","(HbGM)");
INSERT INTO `catalogo_campos` VALUES("47","2",NULL,"1","40.0 - 70.0","%","NEUTROFILOS");
INSERT INTO `catalogo_campos` VALUES("48","2",NULL,"1","20.0 - 50.0","%","LINFOCITOS");
INSERT INTO `catalogo_campos` VALUES("49","2",NULL,"1","3.0 - 5.0","%","EOSINOFILOS");
INSERT INTO `catalogo_campos` VALUES("50","2",NULL,"1","1.0 - 2.0","%","BASOFILOS");
INSERT INTO `catalogo_campos` VALUES("51","2",NULL,"1","0.0 - 1.0","%","MONOCITOS");
INSERT INTO `catalogo_campos` VALUES("52","2",NULL,"1","150.0 - 450.0","xmmc","PLAQUETAS");
INSERT INTO `catalogo_campos` VALUES("53","3",NULL,"1",NULL,"%","RETICULOCITOS");
INSERT INTO `catalogo_campos` VALUES("54","3",NULL,"1",NULL,".","BACTERIA AISLADA");
INSERT INTO `catalogo_campos` VALUES("55","3",NULL,"1",NULL,"ARH","TIPO SANGINEO");
INSERT INTO `catalogo_campos` VALUES("56","2",NULL,"1","Hasta 152.0","mm. x hora","ERITROSEDIMENTACIÓN");



DROP TABLE IF EXISTS `catalogo_materiales`;

CREATE TABLE `catalogo_materiales` (
  `id` varchar(50) NOT NULL,
  `nombre_catalogo` varchar(60) NOT NULL,
  `fecha_vencimiento` int(11) NOT NULL DEFAULT '0',
  `is_fecha_vencimiento` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AVG_ROW_LENGTH=8192;

INSERT INTO `catalogo_materiales` VALUES("1aac964e-994f-4415-ab4e-439d3f9495d4","Reactivos","1","1");
INSERT INTO `catalogo_materiales` VALUES("c946e5fe-dcdc-4e13-a685-58f9ad8c4030","Insumos","0","0");



DROP TABLE IF EXISTS `categorias_examenes`;

CREATE TABLE `categorias_examenes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nombre_categoria` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1 AVG_ROW_LENGTH=3276;

INSERT INTO `categorias_examenes` VALUES("1","Varios");
INSERT INTO `categorias_examenes` VALUES("2","Hematologia");
INSERT INTO `categorias_examenes` VALUES("3","Bacteriologias");
INSERT INTO `categorias_examenes` VALUES("4","Quimico Sanguineo");
INSERT INTO `categorias_examenes` VALUES("5","Examenes Comunes");



DROP TABLE IF EXISTS `citas`;

CREATE TABLE `citas` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `paciente_id` varchar(50) DEFAULT NULL,
  `fecha` date DEFAULT NULL,
  `horario` varchar(50) DEFAULT NULL,
  `estado` tinyint(4) DEFAULT NULL,
  `pagar` double(13,2) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

INSERT INTO `citas` VALUES("1","4e3fc936-c72a-4959-b80e-b56c27dcb273","2018-03-06","06:00:00-06:30:00","0","26.00");
INSERT INTO `citas` VALUES("2","4e3fc936-c72a-4959-b80e-b56c27dcb273","2018-03-08","07:00:00-07:30:00","0","53.50");



DROP TABLE IF EXISTS `citas_examenes`;

CREATE TABLE `citas_examenes` (
  `cita_id` int(11) DEFAULT NULL,
  `examen_id` int(11) DEFAULT NULL,
  `precio` double(13,2) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `citas_examenes` VALUES("1","3","11.00");
INSERT INTO `citas_examenes` VALUES("1","4","15.00");
INSERT INTO `citas_examenes` VALUES("2","3","11.00");
INSERT INTO `citas_examenes` VALUES("2","5","27.50");
INSERT INTO `citas_examenes` VALUES("2","4","15.00");



DROP TABLE IF EXISTS `citas_horarios`;

CREATE TABLE `citas_horarios` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `hora_entrada` time DEFAULT NULL,
  `hora_salidad` time DEFAULT NULL,
  `status` tinyint(1) DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=latin1;

INSERT INTO `citas_horarios` VALUES("7","06:00:00","06:30:00","1");
INSERT INTO `citas_horarios` VALUES("8","06:30:00","07:00:00","1");
INSERT INTO `citas_horarios` VALUES("9","07:00:00","07:30:00","1");



DROP TABLE IF EXISTS `compras`;

CREATE TABLE `compras` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `proveedor_id` varchar(50) NOT NULL,
  `sucursal_id` varchar(50) NOT NULL,
  `fecha_compra` datetime NOT NULL,
  `total_compra` double(9,2) NOT NULL,
  `estado` int(11) NOT NULL,
  `codigo_factura` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `proveedor_id` (`proveedor_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1 AVG_ROW_LENGTH=5461;

INSERT INTO `compras` VALUES("1","d9446280-2320-11e7-93ae-92361f002671","725880d6-f625-4a48-926e-6fdb2c9be755","2018-01-21 20:39:56","133.05","0","895AFBD");



DROP TABLE IF EXISTS `compras_items`;

CREATE TABLE `compras_items` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `compra_id` int(11) NOT NULL,
  `material_id` int(11) NOT NULL,
  `estado` int(11) NOT NULL,
  `precio` double(9,2) NOT NULL,
  `cantidad` int(11) NOT NULL,
  `fecha_vencimiento` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `compra_id` (`compra_id`),
  KEY `material_id` (`material_id`)
) ENGINE=InnoDB AUTO_INCREMENT=70 DEFAULT CHARSET=latin1 AVG_ROW_LENGTH=2048;

INSERT INTO `compras_items` VALUES("67","1","5","0","8.69","5","2018-01-24 02:41:01");
INSERT INTO `compras_items` VALUES("68","1","9","0","5.60","8","2018-01-24 02:41:16");
INSERT INTO `compras_items` VALUES("69","1","1","0","5.60","8","2018-01-22 02:41:22");



DROP TABLE IF EXISTS `configuration`;

CREATE TABLE `configuration` (
  `configuration_id` int(11) NOT NULL AUTO_INCREMENT,
  `name_campus` varchar(30) NOT NULL,
  `value_campus` varchar(20) NOT NULL,
  PRIMARY KEY (`configuration_id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1 AVG_ROW_LENGTH=3276;

INSERT INTO `configuration` VALUES("1","empleado","11");
INSERT INTO `configuration` VALUES("2","sucursal","7");
INSERT INTO `configuration` VALUES("3","paciente","14");
INSERT INTO `configuration` VALUES("4","isss","0.205");
INSERT INTO `configuration` VALUES("5","afp","0.89");



DROP TABLE IF EXISTS `doctores`;

CREATE TABLE `doctores` (
  `id` varchar(50) NOT NULL,
  `jvpm_doc` varchar(5) NOT NULL,
  `name_doc` varchar(30) NOT NULL,
  `lastname_doc` varchar(45) NOT NULL,
  `email` varchar(100) NOT NULL,
  `phone_doc` varchar(10) NOT NULL,
  `nit` varchar(20) NOT NULL,
  `nrc` varchar(10) NOT NULL,
  `status` int(11) NOT NULL DEFAULT '1',
  `lat` varchar(15) DEFAULT NULL,
  `lng` varchar(15) DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AVG_ROW_LENGTH=4096;

INSERT INTO `doctores` VALUES("1","43543","Edwin Antonio","Melara Landaverde","edwin.melara@gmail.com","7876-9873","85775757777657","9885788","1","13.642900704022","-88.79230856895","2017-11-07 21:31:38","2017-11-07 00:00:00");
INSERT INTO `doctores` VALUES("2cf6c555-87d5-469c-9063-a6a19fd1128e","00451","Juan Jose","Lopez Gonzales","jua.jose@gmail.com","78547847","05210305901024","0045158","1","13.642307","-88.784270","2018-01-24 04:43:47","2018-01-14 13:52:29");
INSERT INTO `doctores` VALUES("7a48599f-14c1-4776-8570-8534d5f7fe96","2314","Dúncan","D\'marco","ddmarco@gmail.com","55555555","10101203571002","2433544","0","13.642307","-88.784270","2018-03-16 21:12:37","2018-01-14 13:53:41");



DROP TABLE IF EXISTS `empleado_usuario`;

CREATE TABLE `empleado_usuario` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `empleado_id` varchar(50) NOT NULL,
  `usuario_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `empleado_id` (`empleado_id`),
  KEY `usuario_id` (`usuario_id`),
  CONSTRAINT `empleado_usuario_ibfk_1` FOREIGN KEY (`empleado_id`) REFERENCES `empleados` (`id`),
  CONSTRAINT `empleado_usuario_ibfk_2` FOREIGN KEY (`usuario_id`) REFERENCES `usuarios` (`id_user`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1 AVG_ROW_LENGTH=5461;

INSERT INTO `empleado_usuario` VALUES("1","514edfbc-eb56-46ff-bbbc-a355fe8bee5b","1");
INSERT INTO `empleado_usuario` VALUES("2","40489ee4-3d07-4d0d-b876-f0ef599d179b","2");
INSERT INTO `empleado_usuario` VALUES("3","caac4d4e-d3ab-4cbc-922d-260fa2c25fb1","3");



DROP TABLE IF EXISTS `empleados`;

CREATE TABLE `empleados` (
  `id` varchar(50) NOT NULL,
  `sucursal_id` varchar(50) NOT NULL,
  `code_emp` varchar(10) NOT NULL,
  `name_emp` varchar(25) NOT NULL,
  `lastname_emp` varchar(25) NOT NULL,
  `tipo_contratacion` varchar(1) NOT NULL DEFAULT '1',
  `salary_day` decimal(9,2) NOT NULL,
  `address_emp` varchar(100) NOT NULL,
  `phone_emp` varchar(9) NOT NULL,
  `fecha_contratacion_emp` date NOT NULL,
  `cargo_emp` varchar(25) NOT NULL DEFAULT 'San Vicente',
  `salary_emp` decimal(9,2) NOT NULL,
  `status` int(11) NOT NULL DEFAULT '1',
  `updated_at` datetime DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `sucursal_id` (`sucursal_id`),
  CONSTRAINT `empleados_ibfk_1` FOREIGN KEY (`sucursal_id`) REFERENCES `sucursales` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AVG_ROW_LENGTH=4096;

INSERT INTO `empleados` VALUES("40489ee4-3d07-4d0d-b876-f0ef599d179b","0e95ed37-0480-437c-8606-40b412e71647","ML17004","Juan Jose","Martinez Lopez","1","15.00","Cojutepeque, Cuscatlan","22343322","2001-09-20","Empleado","450.00","1","2017-10-21 20:37:49","2017-05-06 22:40:09");
INSERT INTO `empleados` VALUES("514edfbc-eb56-46ff-bbbc-a355fe8bee5b","725880d6-f625-4a48-926e-6fdb2c9be755","PS17005","Ana Maria","Perez Sosa","2","10.00","calle al hospital nacional, San Vicente, el salvador","67887777","2017-07-19","Laboratonista","300.00","1","2017-11-19 19:07:09","2017-05-23 13:27:23");
INSERT INTO `empleados` VALUES("8fd2ece3-817b-4523-960d-328988bd1cd2","725880d6-f625-4a48-926e-6fdb2c9be755","RV170010","Erika del Rosario","Rafael Ventura","1","9.70","San Salvador, calle a los pinos","78777666","2017-10-21","Secretaria","290.89","1","2017-10-21 20:41:50","2017-10-21 20:41:50");
INSERT INTO `empleados` VALUES("b65c5a84-b9c6-430e-9b3e-d4d7f2fc0dc9","725880d6-f625-4a48-926e-6fdb2c9be755","RV17009","Erika del Rosario","Rafael Ventura","1","9.70","San Salvador, calle a los pinos","78777666","2017-10-21","Secretaria","290.89","1","2017-10-21 20:41:49","2017-10-21 20:41:49");
INSERT INTO `empleados` VALUES("caac4d4e-d3ab-4cbc-922d-260fa2c25fb1","725880d6-f625-4a48-926e-6fdb2c9be755","CM17006","Diego Armando","Cruz Martinez","1","7.50","Zacatecolucas","78986756","2017-10-28","Ordenanza","225.00","1","2017-10-21 20:52:47","2017-05-23 13:30:48");
INSERT INTO `empleados` VALUES("df331d54-22e3-11e7-93ae-92361f002671","0e95ed37-0480-437c-8606-40b412e71647","ML17001","Mirian","Ramos Carcamo","2","0.00","Cojutepeque, El salvador","77458501","2017-04-16","Empleado","2000.00","1","2017-05-23 13:24:10","2017-04-16 14:33:33");



DROP TABLE IF EXISTS `entidad_monto`;

CREATE TABLE `entidad_monto` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_entidad` varchar(50) NOT NULL,
  `monto` double(13,2) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1 AVG_ROW_LENGTH=8192;

INSERT INTO `entidad_monto` VALUES("2","dab6a9cb-17ad-4515-a8ed-bebf4e8a1e03","5.00");
INSERT INTO `entidad_monto` VALUES("3","63a22aae-79c1-4255-91b7-41a2477fc207","246.40");



DROP TABLE IF EXISTS `entidades`;

CREATE TABLE `entidades` (
  `id` varchar(50) NOT NULL,
  `name_ext` varchar(50) NOT NULL,
  `address_ext` varchar(75) NOT NULL,
  `phone_ext` varchar(8) NOT NULL,
  `nit_entidad` varchar(20) NOT NULL,
  `nrc_entidad` varchar(10) NOT NULL,
  `represent_ext` varchar(25) NOT NULL,
  `phone_represent_ext` varchar(8) NOT NULL,
  `mail_represent_ext` varchar(50) NOT NULL,
  `view` int(11) NOT NULL DEFAULT '1',
  `status` int(1) NOT NULL DEFAULT '1',
  `updated_at` datetime DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AVG_ROW_LENGTH=5461;

INSERT INTO `entidades` VALUES("1b6ef36f-b05b-4c35-910d-661f86fde307","Particular","N/A","N/A","N/A","N/A","N/A","N/A","N/A","0","1","2017-06-14 06:17:31","2017-06-14 06:17:31");
INSERT INTO `entidades` VALUES("63a22aae-79c1-4255-91b7-41a2477fc207","Instituto Nacional del Seguro Social ","San salvador centro","23057895","05740588878549","7854748547","Edwin Melara Landaverde","78547847","melara0606@gmail.com","1","1","2018-02-06 12:33:08","2017-04-16 13:43:20");
INSERT INTO `entidades` VALUES("dab6a9cb-17ad-4515-a8ed-bebf4e8a1e03","Pizza Hut El Salvador","San Salvador, el salvador, el salvador","22301548","78547847854478","7784478477","Juan Miguel Lopez","78578457","pizza@pizza.com.sv","1","1","2017-10-21 21:17:31","2017-04-16 13:51:08");



DROP TABLE IF EXISTS `entidades_examenes`;

CREATE TABLE `entidades_examenes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_entidad` varchar(50) DEFAULT NULL,
  `id_examen` int(11) DEFAULT NULL,
  `precio` double(13,2) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=35 DEFAULT CHARSET=latin1 AVG_ROW_LENGTH=4096;

INSERT INTO `entidades_examenes` VALUES("31","dab6a9cb-17ad-4515-a8ed-bebf4e8a1e03","4","9.60");
INSERT INTO `entidades_examenes` VALUES("32","dab6a9cb-17ad-4515-a8ed-bebf4e8a1e03","5","9.60");
INSERT INTO `entidades_examenes` VALUES("33","63a22aae-79c1-4255-91b7-41a2477fc207","4","9.60");
INSERT INTO `entidades_examenes` VALUES("34","63a22aae-79c1-4255-91b7-41a2477fc207","5","9.60");



DROP TABLE IF EXISTS `examen_campo`;

CREATE TABLE `examen_campo` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `examen_id` int(11) DEFAULT NULL,
  `catalogo_campo_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_campo_catalogo` (`catalogo_campo_id`),
  KEY `fk_examen` (`examen_id`),
  CONSTRAINT `fk_campo_catalogo` FOREIGN KEY (`catalogo_campo_id`) REFERENCES `catalogo_campos` (`id`) ON UPDATE CASCADE,
  CONSTRAINT `fk_examen` FOREIGN KEY (`examen_id`) REFERENCES `examenes` (`id`) ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=77 DEFAULT CHARSET=latin1 AVG_ROW_LENGTH=240;

INSERT INTO `examen_campo` VALUES("8","3","2");
INSERT INTO `examen_campo` VALUES("10","8","5");
INSERT INTO `examen_campo` VALUES("11","3","3");
INSERT INTO `examen_campo` VALUES("12","3","6");
INSERT INTO `examen_campo` VALUES("13","3","7");
INSERT INTO `examen_campo` VALUES("14","3","8");
INSERT INTO `examen_campo` VALUES("15","3","9");
INSERT INTO `examen_campo` VALUES("16","3","10");
INSERT INTO `examen_campo` VALUES("17","3","11");
INSERT INTO `examen_campo` VALUES("18","3","17");
INSERT INTO `examen_campo` VALUES("19","3","13");
INSERT INTO `examen_campo` VALUES("20","3","12");
INSERT INTO `examen_campo` VALUES("21","3","15");
INSERT INTO `examen_campo` VALUES("22","3","14");
INSERT INTO `examen_campo` VALUES("23","3","16");
INSERT INTO `examen_campo` VALUES("24","3","19");
INSERT INTO `examen_campo` VALUES("25","3","20");
INSERT INTO `examen_campo` VALUES("26","4","2");
INSERT INTO `examen_campo` VALUES("27","4","3");
INSERT INTO `examen_campo` VALUES("28","4","19");
INSERT INTO `examen_campo` VALUES("29","4","6");
INSERT INTO `examen_campo` VALUES("30","4","7");
INSERT INTO `examen_campo` VALUES("31","4","9");
INSERT INTO `examen_campo` VALUES("32","4","10");
INSERT INTO `examen_campo` VALUES("33","4","11");
INSERT INTO `examen_campo` VALUES("34","4","17");
INSERT INTO `examen_campo` VALUES("35","4","18");
INSERT INTO `examen_campo` VALUES("36","4","21");
INSERT INTO `examen_campo` VALUES("37","4","23");
INSERT INTO `examen_campo` VALUES("38","5","2");
INSERT INTO `examen_campo` VALUES("39","5","3");
INSERT INTO `examen_campo` VALUES("40","5","6");
INSERT INTO `examen_campo` VALUES("41","5","19");
INSERT INTO `examen_campo` VALUES("42","5","9");
INSERT INTO `examen_campo` VALUES("43","5","10");
INSERT INTO `examen_campo` VALUES("44","5","17");
INSERT INTO `examen_campo` VALUES("45","5","25");
INSERT INTO `examen_campo` VALUES("46","5","24");
INSERT INTO `examen_campo` VALUES("47","5","20");
INSERT INTO `examen_campo` VALUES("48","6","55");
INSERT INTO `examen_campo` VALUES("49","7","52");
INSERT INTO `examen_campo` VALUES("50","9","56");
INSERT INTO `examen_campo` VALUES("51","10","53");
INSERT INTO `examen_campo` VALUES("52","11","40");
INSERT INTO `examen_campo` VALUES("53","11","41");
INSERT INTO `examen_campo` VALUES("54","11","42");
INSERT INTO `examen_campo` VALUES("55","11","43");
INSERT INTO `examen_campo` VALUES("56","11","44");
INSERT INTO `examen_campo` VALUES("57","11","45");
INSERT INTO `examen_campo` VALUES("58","11","46");
INSERT INTO `examen_campo` VALUES("59","11","47");
INSERT INTO `examen_campo` VALUES("60","11","48");
INSERT INTO `examen_campo` VALUES("61","11","49");
INSERT INTO `examen_campo` VALUES("62","11","51");
INSERT INTO `examen_campo` VALUES("63","11","50");
INSERT INTO `examen_campo` VALUES("64","26","1");
INSERT INTO `examen_campo` VALUES("65","12","27");
INSERT INTO `examen_campo` VALUES("66","13","28");
INSERT INTO `examen_campo` VALUES("67","14","29");
INSERT INTO `examen_campo` VALUES("68","15","30");
INSERT INTO `examen_campo` VALUES("69","16","31");
INSERT INTO `examen_campo` VALUES("70","17","32");
INSERT INTO `examen_campo` VALUES("71","18","33");
INSERT INTO `examen_campo` VALUES("72","19","34");
INSERT INTO `examen_campo` VALUES("73","20","35");
INSERT INTO `examen_campo` VALUES("74","21","36");
INSERT INTO `examen_campo` VALUES("75","24","38");
INSERT INTO `examen_campo` VALUES("76","25","39");



DROP TABLE IF EXISTS `examenes`;

CREATE TABLE `examenes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `categoria_id` int(11) NOT NULL,
  `nombre_examen` varchar(50) NOT NULL,
  `precio` double(13,2) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=27 DEFAULT CHARSET=latin1 AVG_ROW_LENGTH=682;

INSERT INTO `examenes` VALUES("3","3","CULTIVO DE SECRECIÓN","11.00");
INSERT INTO `examenes` VALUES("4","3","CULTIVO FARINGEO","15.00");
INSERT INTO `examenes` VALUES("5","3","HEMOCULTIVO","27.50");
INSERT INTO `examenes` VALUES("6","5","TIPEO SANGUÍNEO","10.00");
INSERT INTO `examenes` VALUES("7","2","PLAQUETAS","2.00");
INSERT INTO `examenes` VALUES("8","1","PATERNIDAD","15.00");
INSERT INTO `examenes` VALUES("9","2","ERITROSEDIMENTACION","7.00");
INSERT INTO `examenes` VALUES("10","2","RETICULOCITOS","4.00");
INSERT INTO `examenes` VALUES("11","2","HEMOGRAMA","3.00");
INSERT INTO `examenes` VALUES("12","4","GLUCOSA","3.00");
INSERT INTO `examenes` VALUES("13","4","GLUCOSA POST-PANDRIAL","9.00");
INSERT INTO `examenes` VALUES("14","4","COLESTEROL TOTAL","3.50");
INSERT INTO `examenes` VALUES("15","4","TRIGLISERIDOS","4.50");
INSERT INTO `examenes` VALUES("16","4","ÁCIDO URICO","5.99");
INSERT INTO `examenes` VALUES("17","4","CREATININA","5.00");
INSERT INTO `examenes` VALUES("18","4","NITRÓGENO UREICO","7.99");
INSERT INTO `examenes` VALUES("19","4","TRANSAMINASA TGO","12.00");
INSERT INTO `examenes` VALUES("20","4","TRANSAMINASA TGP","12.00");
INSERT INTO `examenes` VALUES("21","4","BILIRUBINA TOTAL","6.00");
INSERT INTO `examenes` VALUES("22","4","BILIRUBONA DIRECTA","7.00");
INSERT INTO `examenes` VALUES("23","4","BILIRUBINA INDIRECTA","7.00");
INSERT INTO `examenes` VALUES("24","4","CALCIO","3.00");
INSERT INTO `examenes` VALUES("25","4","POTASIO","9.80");
INSERT INTO `examenes` VALUES("26","4","SODIO","8.99");



DROP TABLE IF EXISTS `examenes_materiales`;

CREATE TABLE `examenes_materiales` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_material` varchar(75) DEFAULT NULL,
  `id_examen` int(11) DEFAULT NULL,
  `uso` double(10,2) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=latin1 AVG_ROW_LENGTH=4096;

INSERT INTO `examenes_materiales` VALUES("16","5","6","8.00");
INSERT INTO `examenes_materiales` VALUES("17","5","3","8.00");
INSERT INTO `examenes_materiales` VALUES("18","7","3","9.00");
INSERT INTO `examenes_materiales` VALUES("19","1","5","10.00");



DROP TABLE IF EXISTS `inventario`;

CREATE TABLE `inventario` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `material_id` int(11) NOT NULL,
  `sucursal` varchar(50) NOT NULL,
  `existencia` bigint(9) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `material_id` (`material_id`),
  KEY `sucursal` (`sucursal`),
  CONSTRAINT `inventario_ibfk_1` FOREIGN KEY (`material_id`) REFERENCES `materiales` (`id`),
  CONSTRAINT `inventario_ibfk_2` FOREIGN KEY (`sucursal`) REFERENCES `sucursales` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1 AVG_ROW_LENGTH=8192;

INSERT INTO `inventario` VALUES("1","5","725880d6-f625-4a48-926e-6fdb2c9be755","500");
INSERT INTO `inventario` VALUES("2","9","725880d6-f625-4a48-926e-6fdb2c9be755","3900");
INSERT INTO `inventario` VALUES("3","1","725880d6-f625-4a48-926e-6fdb2c9be755","1270");



DROP TABLE IF EXISTS `inventario_reajuste`;

CREATE TABLE `inventario_reajuste` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `invetario_id` int(11) DEFAULT NULL,
  `usuario_id` int(11) DEFAULT NULL,
  `cantidad` float DEFAULT NULL,
  `fecha` datetime DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  `motivo` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_invetario` (`invetario_id`),
  KEY `fk_users` (`usuario_id`),
  CONSTRAINT `fk_invetario` FOREIGN KEY (`invetario_id`) REFERENCES `inventario` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_users` FOREIGN KEY (`usuario_id`) REFERENCES `usuarios` (`id_user`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=latin1;

INSERT INTO `inventario_reajuste` VALUES("8","3","1","17","2018-02-05 22:59:28","se rompio.");
INSERT INTO `inventario_reajuste` VALUES("9","3","1","30","2018-02-05 23:00:18","se rompio el ultimo frasco que se compro.");
INSERT INTO `inventario_reajuste` VALUES("10","2","1","20","2018-02-05 23:00:39","se equivo la compra.");
INSERT INTO `inventario_reajuste` VALUES("11","2","1","80","2018-02-05 23:03:55","se rompio un frasco.");



DROP TABLE IF EXISTS `materiales`;

CREATE TABLE `materiales` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `catalogo_id` varchar(50) NOT NULL,
  `nombre_material` varchar(50) NOT NULL,
  `presentancion` varchar(1) NOT NULL,
  `unidades` int(11) NOT NULL,
  `update_create` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `catalogo_id` (`catalogo_id`)
) ENGINE=InnoDB AUTO_INCREMENT=78 DEFAULT CHARSET=latin1 AVG_ROW_LENGTH=1260;

INSERT INTO `materiales` VALUES("1","c946e5fe-dcdc-4e13-a685-58f9ad8c4030","Inyecciones 3ml","1","180","2017-07-16 22:14:56");
INSERT INTO `materiales` VALUES("2","c946e5fe-dcdc-4e13-a685-58f9ad8c4030","Algodon","1","250","2017-07-16 22:03:23");
INSERT INTO `materiales` VALUES("3","1aac964e-994f-4415-ab4e-439d3f9495d4","Liquido Mediano 20","2","100","2017-10-28 22:09:53");
INSERT INTO `materiales` VALUES("4","1aac964e-994f-4415-ab4e-439d3f9495d4","San Jose","1","200","2017-07-17 10:38:34");
INSERT INTO `materiales` VALUES("5","1aac964e-994f-4415-ab4e-439d3f9495d4","aceite manueles","1","100","2017-07-16 22:03:23");
INSERT INTO `materiales` VALUES("6","c946e5fe-dcdc-4e13-a685-58f9ad8c4030","caja","1","200","2017-07-16 22:03:23");
INSERT INTO `materiales` VALUES("7","1aac964e-994f-4415-ab4e-439d3f9495d4","valeverguina x-23","2","100","2017-07-16 22:03:23");
INSERT INTO `materiales` VALUES("8","1aac964e-994f-4415-ab4e-439d3f9495d4","mierdanacil b133","1","25","2017-07-16 22:03:23");
INSERT INTO `materiales` VALUES("9","1aac964e-994f-4415-ab4e-439d3f9495d4","osculianato sodico 45g","2","500","2017-07-16 22:03:23");
INSERT INTO `materiales` VALUES("10","c946e5fe-dcdc-4e13-a685-58f9ad8c4030","jeringas 3ml","2","100","2017-07-16 22:03:23");
INSERT INTO `materiales` VALUES("13","1aac964e-994f-4415-ab4e-439d3f9495d4","dese mismo 23g","1","250","2017-10-28 22:10:10");
INSERT INTO `materiales` VALUES("58","c946e5fe-dcdc-4e13-a685-58f9ad8c4030","agujas 2ml","2","960","2017-07-16 22:13:46");
INSERT INTO `materiales` VALUES("77","c946e5fe-dcdc-4e13-a685-58f9ad8c4030","Cojutepeque 20","2","9850","2017-10-28 22:09:21");



DROP TABLE IF EXISTS `monto_historial`;

CREATE TABLE `monto_historial` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_monto` int(11) DEFAULT NULL,
  `monto` double(13,2) DEFAULT NULL,
  `fecha_ingreso` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=latin1 AVG_ROW_LENGTH=4096;

INSERT INTO `monto_historial` VALUES("3","2","10.00","2017-08-20 10:24:12");
INSERT INTO `monto_historial` VALUES("4","2","689.00","2017-08-20 10:24:31");
INSERT INTO `monto_historial` VALUES("5","2","89.09","2017-08-20 10:24:54");
INSERT INTO `monto_historial` VALUES("6","3","150.00","2017-08-28 06:17:23");
INSERT INTO `monto_historial` VALUES("7","3","250.00","2018-02-11 01:38:33");



DROP TABLE IF EXISTS `noticias`;

CREATE TABLE `noticias` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `titulo` varchar(50) DEFAULT NULL,
  `fecha` datetime DEFAULT NULL,
  `user_created` varchar(50) DEFAULT NULL,
  `user_update` varchar(50) DEFAULT NULL,
  `created_date` datetime DEFAULT NULL,
  `publisher` tinyint(4) DEFAULT NULL,
  `body` text,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

INSERT INTO `noticias` VALUES("4","Granizada en el D.F","2018-03-11 23:17:33","a@gmail.com","a@gmail.com","2018-03-11 23:14:05","1","<div><!--block--><em>México D.F 3 de Junio de 2015.- Granizada ataca al Distrito Federal: El pasado 3 de junio una granizada calló en la ciudad de México, dejando destrozos y caos tras de sí, varias delegaciones, afectando a la delegación Miguel Hidalgo, Cuauhtémoc, Iztacalco, Venustiano Carranza e Iztapalapa.</em><br><br></div><ol><li><!--block--><em>Los efectos de este fenómeno natural fueron principalmente el granizo en&nbsp; la vialidad, donde se vieron encharcamientos y cúmulos de granizo.</em></li></ol><div><!--block--><br></div><blockquote><!--block--><em>Este fenómeno alcanzó a cerrar la vialidad en la carretera México Toluca, la cual se reabrió hasta el día siguiente, que las obras y el tiempo lo permitieron, también hubo afectación en otras vialidades principales, pero sin llegar al cierre de las mismas.</em></blockquote><div><!--block--><br></div><div><!--block-->URL del artículo: <a href=\"http://www.ejemplode.com/44-redaccion/3209-ejemplo_de_noticia.html\">Articulo</a></div>");



DROP TABLE IF EXISTS `pacientes`;

CREATE TABLE `pacientes` (
  `id` varchar(50) NOT NULL,
  `codigo_paciente` varchar(15) NOT NULL,
  `password` varchar(200) DEFAULT NULL,
  `entidad_id` varchar(50) NOT NULL,
  `name_pac` varchar(25) NOT NULL,
  `lastname_pac` varchar(25) NOT NULL,
  `telefono` varchar(10) DEFAULT NULL,
  `carnet` varchar(15) DEFAULT NULL,
  `dui` varchar(10) DEFAULT NULL,
  `address_pac` varchar(100) DEFAULT NULL,
  `date_pac` date NOT NULL,
  `genero_paciente` varchar(2) NOT NULL,
  `responsable_paciente` varchar(50) DEFAULT NULL,
  `status` int(11) NOT NULL DEFAULT '0',
  `updated_at` datetime DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `codigo_paciente` (`codigo_paciente`),
  KEY `entidad_id` (`entidad_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AVG_ROW_LENGTH=3276;

INSERT INTO `pacientes` VALUES("4e3fc936-c72a-4959-b80e-b56c27dcb273","PR004","$6$admin$Pvh8qetYOf6uoVEDQDa49mSXOfkDh/EeFkrxi3yc0qN/dSTVR5iyFpbwbtgp7bPBjGZQ8Uz/MiZCAPuwjSD0w1","dab6a9cb-17ad-4515-a8ed-bebf4e8a1e03","angelica rosalie","peacles rissotto","64355455","ap0223","031324456","-","1968-08-19","2","-","1","2017-10-21 20:30:53","2017-06-10 18:05:23");
INSERT INTO `pacientes` VALUES("a5012e2d-91f2-4ceb-835c-1786651f01b4","RR0013","$6$admin$Pvh8qetYOf6uoVEDQDa49mSXOfkDh/EeFkrxi3yc0qN/dSTVR5iyFpbwbtgp7bPBjGZQ8Uz/MiZCAPuwjSD0w1","63a22aae-79c1-4255-91b7-41a2477fc207","Karina","Roland",NULL,NULL,NULL,NULL,"2017-11-24","1",NULL,"1","2017-11-23 23:50:31","2017-11-23 23:50:31");
INSERT INTO `pacientes` VALUES("a81a4690-4769-4d35-81fc-df13fe7e0484","DL007","$6$admin$Pvh8qetYOf6uoVEDQDa49mSXOfkDh/EeFkrxi3yc0qN/dSTVR5iyFpbwbtgp7bPBjGZQ8Uz/MiZCAPuwjSD0w1","63a22aae-79c1-4255-91b7-41a2477fc207","Juan manuel","De La O","76894567","CP003","098383663","Cojutepeque, Cuscatlan","2017-07-17","1","Juan Manuel Lopez","1","2017-07-17 09:55:11","2017-07-17 09:55:11");



DROP TABLE IF EXISTS `perfil_recursos`;

CREATE TABLE `perfil_recursos` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `consultar` tinyint(4) NOT NULL,
  `agregar` tinyint(4) NOT NULL,
  `editar` tinyint(4) NOT NULL,
  `eliminar` tinyint(4) NOT NULL,
  `recurso_id` int(11) NOT NULL,
  `perfil_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `perfil_id` (`perfil_id`),
  KEY `recurso_id` (`recurso_id`),
  CONSTRAINT `perfil_recursos_ibfk_2` FOREIGN KEY (`recurso_id`) REFERENCES `recursos` (`id`),
  CONSTRAINT `perfil_recursos_ibfk_3` FOREIGN KEY (`perfil_id`) REFERENCES `perfiles` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=177 DEFAULT CHARSET=latin1 AVG_ROW_LENGTH=2340;

INSERT INTO `perfil_recursos` VALUES("76","1","1","1","1","18","6");
INSERT INTO `perfil_recursos` VALUES("78","1","1","1","1","11","1");
INSERT INTO `perfil_recursos` VALUES("166","1","1","1","1","17","1");
INSERT INTO `perfil_recursos` VALUES("169","1","1","1","1","20","1");
INSERT INTO `perfil_recursos` VALUES("170","1","1","0","0","12","1");
INSERT INTO `perfil_recursos` VALUES("171","1","0","0","0","24","1");
INSERT INTO `perfil_recursos` VALUES("172","1","1","1","1","22","1");
INSERT INTO `perfil_recursos` VALUES("173","1","1","1","1","7","1");
INSERT INTO `perfil_recursos` VALUES("174","1","1","1","1","1","1");
INSERT INTO `perfil_recursos` VALUES("175","1","1","1","1","10","1");
INSERT INTO `perfil_recursos` VALUES("176","1","1","1","1","13","1");



DROP TABLE IF EXISTS `perfiles`;

CREATE TABLE `perfiles` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(100) NOT NULL,
  `fecha_registro` datetime NOT NULL,
  `is_view` tinyint(1) DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1 AVG_ROW_LENGTH=5461;

INSERT INTO `perfiles` VALUES("1","Administradores","2017-06-04 00:00:00","1");
INSERT INTO `perfiles` VALUES("2","Usuarios","2017-06-04 00:00:00","1");
INSERT INTO `perfiles` VALUES("5","Secretaria","2017-07-28 22:21:31","1");
INSERT INTO `perfiles` VALUES("6","Pacientes","2017-10-16 12:02:13","0");



DROP TABLE IF EXISTS `permisos_comentarios`;

CREATE TABLE `permisos_comentarios` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `permiso_id` int(11) NOT NULL,
  `comentario` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `permiso_id` (`permiso_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;




DROP TABLE IF EXISTS `permisos_incapacidades`;

CREATE TABLE `permisos_incapacidades` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `empleado_id` varchar(50) NOT NULL,
  `fecha_inicio` date NOT NULL,
  `fecha_fin` date NOT NULL,
  `tipo` int(1) NOT NULL,
  `is_descuento` int(1) NOT NULL,
  `days_permisos` int(11) NOT NULL,
  `created_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `empleado_id` (`empleado_id`)
) ENGINE=InnoDB AUTO_INCREMENT=41 DEFAULT CHARSET=latin1 AVG_ROW_LENGTH=780;

INSERT INTO `permisos_incapacidades` VALUES("40","40489ee4-3d07-4d0d-b876-f0ef599d179b","2017-11-08","2017-11-11","2","0","4","2017-11-08 00:38:56");



DROP TABLE IF EXISTS `permisos_incapacidades_fechas`;

CREATE TABLE `permisos_incapacidades_fechas` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `permiso_id` int(11) NOT NULL,
  `fecha` date NOT NULL,
  PRIMARY KEY (`id`),
  KEY `permiso_id` (`permiso_id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=100 DEFAULT CHARSET=latin1;

INSERT INTO `permisos_incapacidades_fechas` VALUES("84","36","2017-11-07");
INSERT INTO `permisos_incapacidades_fechas` VALUES("85","36","2017-11-08");
INSERT INTO `permisos_incapacidades_fechas` VALUES("86","36","2017-11-09");
INSERT INTO `permisos_incapacidades_fechas` VALUES("87","37","2017-11-10");
INSERT INTO `permisos_incapacidades_fechas` VALUES("88","37","2017-11-11");
INSERT INTO `permisos_incapacidades_fechas` VALUES("89","37","2017-11-12");
INSERT INTO `permisos_incapacidades_fechas` VALUES("90","37","2017-11-13");
INSERT INTO `permisos_incapacidades_fechas` VALUES("91","38","2017-12-03");
INSERT INTO `permisos_incapacidades_fechas` VALUES("92","39","2017-11-09");
INSERT INTO `permisos_incapacidades_fechas` VALUES("93","39","2017-11-10");
INSERT INTO `permisos_incapacidades_fechas` VALUES("94","39","2017-11-11");
INSERT INTO `permisos_incapacidades_fechas` VALUES("95","39","2017-11-12");
INSERT INTO `permisos_incapacidades_fechas` VALUES("96","40","2017-11-08");
INSERT INTO `permisos_incapacidades_fechas` VALUES("97","40","2017-11-09");
INSERT INTO `permisos_incapacidades_fechas` VALUES("98","40","2017-11-10");
INSERT INTO `permisos_incapacidades_fechas` VALUES("99","40","2017-11-11");



DROP TABLE IF EXISTS `planilla_empleado`;

CREATE TABLE `planilla_empleado` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `planilla_id` int(11) NOT NULL,
  `empleado_id` varchar(50) NOT NULL,
  `isss` float(13,2) NOT NULL,
  `afp` float(13,2) NOT NULL,
  `renta` float(13,2) NOT NULL,
  `otros` float(13,2) NOT NULL,
  `salario` float(13,2) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `empleado_id` (`empleado_id`),
  KEY `planilla_id` (`planilla_id`),
  CONSTRAINT `planilla_empleado_ibfk_2` FOREIGN KEY (`empleado_id`) REFERENCES `empleados` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=latin1 AVG_ROW_LENGTH=5461;

INSERT INTO `planilla_empleado` VALUES("15","14","514edfbc-eb56-46ff-bbbc-a355fe8bee5b","0.00","0.00","30.00","0.00","300.00");
INSERT INTO `planilla_empleado` VALUES("16","14","8fd2ece3-817b-4523-960d-328988bd1cd2","0.00","0.00","29.09","0.00","290.89");
INSERT INTO `planilla_empleado` VALUES("17","14","b65c5a84-b9c6-430e-9b3e-d4d7f2fc0dc9","0.00","0.00","29.09","0.00","290.89");
INSERT INTO `planilla_empleado` VALUES("18","14","caac4d4e-d3ab-4cbc-922d-260fa2c25fb1","0.00","0.00","22.50","0.00","225.00");
INSERT INTO `planilla_empleado` VALUES("19","15","40489ee4-3d07-4d0d-b876-f0ef599d179b","0.00","0.00","45.00","94.50","450.00");



DROP TABLE IF EXISTS `planillas`;

CREATE TABLE `planillas` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sucursal_id` varchar(50) NOT NULL,
  `mes_ayor` varchar(10) NOT NULL,
  `fecha_creacion` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=latin1;

INSERT INTO `planillas` VALUES("14","725880d6-f625-4a48-926e-6fdb2c9be755","10/17","2017-10-28 22:05:48");
INSERT INTO `planillas` VALUES("15","0e95ed37-0480-437c-8606-40b412e71647","10/17","2017-10-28 22:07:11");



DROP TABLE IF EXISTS `promocion_examenes`;

CREATE TABLE `promocion_examenes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `promocion_id` int(11) NOT NULL,
  `examen_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `examen_id` (`examen_id`),
  KEY `promocion_id` (`promocion_id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=latin1 AVG_ROW_LENGTH=5461;

INSERT INTO `promocion_examenes` VALUES("5","9","4");
INSERT INTO `promocion_examenes` VALUES("6","9","3");
INSERT INTO `promocion_examenes` VALUES("8","1","4");



DROP TABLE IF EXISTS `promociones`;

CREATE TABLE `promociones` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nombre_promocion` varchar(75) NOT NULL,
  `estado` tinyint(4) NOT NULL,
  `precio` double(13,2) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=latin1 AVG_ROW_LENGTH=5461;

INSERT INTO `promociones` VALUES("1","Promocion 1","1","25.98");
INSERT INTO `promociones` VALUES("8","Component 223","1","12.89");
INSERT INTO `promociones` VALUES("9","promocion 3","1","8.98");



DROP TABLE IF EXISTS `proveedor_materiales`;

CREATE TABLE `proveedor_materiales` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `proveedor_id` varchar(50) NOT NULL,
  `material_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `material_id` (`material_id`),
  KEY `proveedor_id` (`proveedor_id`),
  CONSTRAINT `proveedor_materiales_ibfk_1` FOREIGN KEY (`proveedor_id`) REFERENCES `proveedores` (`id`),
  CONSTRAINT `proveedor_materiales_ibfk_2` FOREIGN KEY (`material_id`) REFERENCES `materiales` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=49 DEFAULT CHARSET=latin1 AVG_ROW_LENGTH=1820;

INSERT INTO `proveedor_materiales` VALUES("22","d9446280-2320-11e7-93ae-92361f002671","7");
INSERT INTO `proveedor_materiales` VALUES("23","9313d5fe-22e6-4d23-b40a-ab4da91fe5ee","3");
INSERT INTO `proveedor_materiales` VALUES("24","9313d5fe-22e6-4d23-b40a-ab4da91fe5ee","4");
INSERT INTO `proveedor_materiales` VALUES("25","9313d5fe-22e6-4d23-b40a-ab4da91fe5ee","5");
INSERT INTO `proveedor_materiales` VALUES("39","d9446280-2320-11e7-93ae-92361f002671","1");
INSERT INTO `proveedor_materiales` VALUES("43","d9446280-2320-11e7-93ae-92361f002671","2");
INSERT INTO `proveedor_materiales` VALUES("44","d9446280-2320-11e7-93ae-92361f002671","9");
INSERT INTO `proveedor_materiales` VALUES("45","d9446280-2320-11e7-93ae-92361f002671","10");
INSERT INTO `proveedor_materiales` VALUES("46","d9446280-2320-11e7-93ae-92361f002671","3");
INSERT INTO `proveedor_materiales` VALUES("47","d9446280-2320-11e7-93ae-92361f002671","4");
INSERT INTO `proveedor_materiales` VALUES("48","d9446280-2320-11e7-93ae-92361f002671","5");



DROP TABLE IF EXISTS `proveedores`;

CREATE TABLE `proveedores` (
  `id` varchar(50) NOT NULL,
  `nombre_proveedor` varchar(100) NOT NULL,
  `direccion_proveedor` text NOT NULL,
  `telefono_proveedor` varchar(10) NOT NULL,
  `nit_proveedor` varchar(20) NOT NULL,
  `nrc_proveedor` varchar(15) NOT NULL,
  `representante_proveedor` varchar(80) NOT NULL,
  `telefono_respresentante` varchar(10) NOT NULL,
  `email_representante` varchar(100) NOT NULL,
  `status` int(11) NOT NULL DEFAULT '1',
  `updated_at` datetime DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AVG_ROW_LENGTH=5461;

INSERT INTO `proveedores` VALUES("9313d5fe-22e6-4d23-b40a-ab4da91fe5ee","ISSS Seguro Social","cojutepeque, san salvador","78544784","78548547895785","8485778454","Juan Ortiz Mendoza","23458178","melara0606@gmail.com","1","2017-11-23 22:53:11","2017-04-16 22:04:10");
INSERT INTO `proveedores` VALUES("d9446280-2320-11e7-93ae-92361f002671","Clinica del Mercado Central, Monte Rosa","Cuidad delgado barrio el centro, san salvador","23007895","0105-060198-101-4","9877878787","Carlos Gonzalez","77848574","ch3charlie@gmail.com","1","2017-11-23 22:56:53","2017-04-16 22:02:37");
INSERT INTO `proveedores` VALUES("e69ecf68-345e-4f23-ae89-21121b05daba","puyasen s.a","esa misma alla en sivar por la sexta decima","22756833","10102310801124","2344422224","raul treviño","78923128","melara0606@gmail.com","1","2017-11-23 22:58:07","2017-06-10 16:49:52");



DROP TABLE IF EXISTS `recursos`;

CREATE TABLE `recursos` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(100) NOT NULL,
  `url` varchar(50) NOT NULL,
  `icons` varchar(50) NOT NULL,
  `view` int(11) NOT NULL DEFAULT '1',
  `isActive` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=latin1 AVG_ROW_LENGTH=963;

INSERT INTO `recursos` VALUES("1","Doctores","doctors","icon-user-follow","1","1");
INSERT INTO `recursos` VALUES("2","Entidades","entidades","icon-graduation","1","1");
INSERT INTO `recursos` VALUES("3","Materiales","insumos_reactivos","icon-cloud-upload","1","1");
INSERT INTO `recursos` VALUES("4","Empleados","personals","icon-users","1","1");
INSERT INTO `recursos` VALUES("5","Proveedores","proveedores","icon-share","1","1");
INSERT INTO `recursos` VALUES("6","Sucursales","sucursales"," icon-folder","1","1");
INSERT INTO `recursos` VALUES("7","Pacientes","pacientes","icon-user-follow","1","1");
INSERT INTO `recursos` VALUES("8","Planillas","planillas","glyphicon glyphicon-calendar","1","1");
INSERT INTO `recursos` VALUES("9","Permisos","permisos","icon-wallet","1","1");
INSERT INTO `recursos` VALUES("10","Compra","compras","icon-basket","1","1");
INSERT INTO `recursos` VALUES("11","Usuarios","usuarios","icon-user-following","1","1");
INSERT INTO `recursos` VALUES("12","Cambio de sucursal","changesucursal","icon-emoticon-smile","0","1");
INSERT INTO `recursos` VALUES("13","Inventario","inventario","icon-credit-card","1","1");
INSERT INTO `recursos` VALUES("14","Examenes","examenes","icon-credit-card","1","1");
INSERT INTO `recursos` VALUES("15","Promociones","promociones","icon-user-unfollow","1","1");
INSERT INTO `recursos` VALUES("16","Campos","catalogocampos","icon-credit-card","1","1");
INSERT INTO `recursos` VALUES("17","Solicitudes","catalogosolicitud","	 icon-credit-card","1","1");
INSERT INTO `recursos` VALUES("18","Perfil","perfil_empleado","icon-social-youtube","0","1");
INSERT INTO `recursos` VALUES("19","Configuracion","rentaconfiguration","icon-social-youtube","1","1");
INSERT INTO `recursos` VALUES("20","Solicitud Adomicilio","solicitudDomicilio","icon-user-unfollow","1","1");
INSERT INTO `recursos` VALUES("21","Citas","citas","icon-user-unfollow","1","1");
INSERT INTO `recursos` VALUES("22","Bitacora","bitacora","icon-user-unfollow","1","1");
INSERT INTO `recursos` VALUES("23","Fecha vencimiento","fechavencimiento","icon-user-unfollow","0","1");
INSERT INTO `recursos` VALUES("24","Noticias","noticias","icon-user-follow","1","1");



DROP TABLE IF EXISTS `renta_valores`;

CREATE TABLE `renta_valores` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `desde_renta` float(13,2) NOT NULL,
  `hasta_renta` float(13,2) NOT NULL,
  `porcentaje_renta` float(5,2) NOT NULL,
  `sobre_exceso` float(13,2) NOT NULL,
  `cuota_fija_renta` float(13,2) NOT NULL,
  `tramo_renta` varchar(10) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1 AVG_ROW_LENGTH=4096;

INSERT INTO `renta_valores` VALUES("1","0.01","567.89","0.00","0.00","0.00","I");
INSERT INTO `renta_valores` VALUES("2","567.90","1345.89","0.16","473.18","17.89","II");
INSERT INTO `renta_valores` VALUES("3","1345.90","3456.90","0.20","895.24","60.00","III");
INSERT INTO `renta_valores` VALUES("4","3456.91","12000.00","0.30","2038.10","288.57","IV");



DROP TABLE IF EXISTS `seleccion_campos`;

CREATE TABLE `seleccion_campos` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nombre_seleccion` varchar(30) DEFAULT NULL,
  `grupo_seleccion` varchar(2) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=latin1 AVG_ROW_LENGTH=3276;

INSERT INTO `seleccion_campos` VALUES("1","SENSIBLES","1");
INSERT INTO `seleccion_campos` VALUES("2","INTERMEDIOS","1");
INSERT INTO `seleccion_campos` VALUES("3","RESISTENTES","1");
INSERT INTO `seleccion_campos` VALUES("4","NEGATIVO","2");
INSERT INTO `seleccion_campos` VALUES("5","POSITIVO","2");
INSERT INTO `seleccion_campos` VALUES("18","pokemon moda","3");



DROP TABLE IF EXISTS `solicitud`;

CREATE TABLE `solicitud` (
  `id` varchar(16) NOT NULL,
  `paciente_id` varchar(50) DEFAULT NULL,
  `sucursal_id` varchar(50) NOT NULL,
  `tipo_solicitud` tinyint(1) DEFAULT NULL,
  `estado` tinyint(1) DEFAULT NULL,
  `fecha_creacion` datetime DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  `monto` float(13,2) DEFAULT NULL,
  `pagoTotal` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AVG_ROW_LENGTH=1365;

INSERT INTO `solicitud` VALUES("ENT16032018001","a81a4690-4769-4d35-81fc-df13fe7e0484","0e95ed37-0480-437c-8606-40b412e71647","3","4","2018-03-16 21:48:51","9.60","0");
INSERT INTO `solicitud` VALUES("ENT16032018002","a81a4690-4769-4d35-81fc-df13fe7e0484","0e95ed37-0480-437c-8606-40b412e71647","3","4","2018-03-16 21:49:48","9.60","0");
INSERT INTO `solicitud` VALUES("PAR01022018001","4e3fc936-c72a-4959-b80e-b56c27dcb273","0e95ed37-0480-437c-8606-40b412e71647","2","4","2018-02-01 18:16:45","27.50","0");
INSERT INTO `solicitud` VALUES("PAR05032018001","4e3fc936-c72a-4959-b80e-b56c27dcb273","725880d6-f625-4a48-926e-6fdb2c9be755","2","0","2018-03-16 21:26:55","32.48","0");
INSERT INTO `solicitud` VALUES("PAR22022018001","4e3fc936-c72a-4959-b80e-b56c27dcb273","0e95ed37-0480-437c-8606-40b412e71647","2","4","2018-02-22 21:10:36","17.00","0");
INSERT INTO `solicitud` VALUES("PRO01022018001","4e3fc936-c72a-4959-b80e-b56c27dcb273","0e95ed37-0480-437c-8606-40b412e71647","1","4","2018-02-01 18:06:44","8.98","1");
INSERT INTO `solicitud` VALUES("PRO01022018002","4e3fc936-c72a-4959-b80e-b56c27dcb273","0e95ed37-0480-437c-8606-40b412e71647","1","4","2018-02-01 18:08:45","8.98","0");
INSERT INTO `solicitud` VALUES("PRO01022018003","4e3fc936-c72a-4959-b80e-b56c27dcb273","0e95ed37-0480-437c-8606-40b412e71647","1","4","2018-02-01 18:09:37","8.98","0");
INSERT INTO `solicitud` VALUES("PRO18022018001","a81a4690-4769-4d35-81fc-df13fe7e0484","0e95ed37-0480-437c-8606-40b412e71647","1","4","2018-02-18 22:40:23","8.98","0");



DROP TABLE IF EXISTS `solicitud_adomicilio`;

CREATE TABLE `solicitud_adomicilio` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `codigo` varchar(25) DEFAULT NULL,
  `sucursal_id` varchar(50) NOT NULL,
  `paciente_id` varchar(50) DEFAULT NULL,
  `lat` double(50,30) DEFAULT NULL,
  `lng` double(50,30) DEFAULT NULL,
  `estado` tinyint(1) DEFAULT '1',
  `pagar` double(13,2) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

INSERT INTO `solicitud_adomicilio` VALUES("1","DOM050318092633","725880d6-f625-4a48-926e-6fdb2c9be755","4e3fc936-c72a-4959-b80e-b56c27dcb273","13.632529961685277000000000000000","-88.787106871604920000000000000000","0","53.50");
INSERT INTO `solicitud_adomicilio` VALUES("2","DOM050318092701","725880d6-f625-4a48-926e-6fdb2c9be755","4e3fc936-c72a-4959-b80e-b56c27dcb273","13.632884465010730000000000000000","-88.787321448326110000000000000000","0","32.48");



DROP TABLE IF EXISTS `solicitud_adomicilio_examenes`;

CREATE TABLE `solicitud_adomicilio_examenes` (
  `solicitud_adomicilio_id` int(11) DEFAULT NULL,
  `examen_id` int(11) DEFAULT NULL,
  `precio` double(13,2) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `solicitud_adomicilio_examenes` VALUES("1","5","27.50");
INSERT INTO `solicitud_adomicilio_examenes` VALUES("1","3","11.00");
INSERT INTO `solicitud_adomicilio_examenes` VALUES("1","4","15.00");
INSERT INTO `solicitud_adomicilio_examenes` VALUES("2","4","15.00");
INSERT INTO `solicitud_adomicilio_examenes` VALUES("2","14","3.50");
INSERT INTO `solicitud_adomicilio_examenes` VALUES("2","16","5.99");
INSERT INTO `solicitud_adomicilio_examenes` VALUES("2","18","7.99");



DROP TABLE IF EXISTS `solicitud_descuento`;

CREATE TABLE `solicitud_descuento` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `solicitud_id` varchar(16) DEFAULT NULL,
  `descuento` float(13,2) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

INSERT INTO `solicitud_descuento` VALUES("1","PRO01022018003","1.00");



DROP TABLE IF EXISTS `solicitud_entidad`;

CREATE TABLE `solicitud_entidad` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `solicitud_id` varchar(16) NOT NULL,
  `entidad_id` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_entidad` (`entidad_id`),
  KEY `fk_solictud` (`solicitud_id`),
  CONSTRAINT `FK_solicitud_entidad_solicitud_id` FOREIGN KEY (`solicitud_id`) REFERENCES `solicitud` (`id`),
  CONSTRAINT `fk_entidad` FOREIGN KEY (`entidad_id`) REFERENCES `entidades` (`id`) ON DELETE NO ACTION ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1 AVG_ROW_LENGTH=8192;

INSERT INTO `solicitud_entidad` VALUES("1","ENT16032018001","63a22aae-79c1-4255-91b7-41a2477fc207");
INSERT INTO `solicitud_entidad` VALUES("2","ENT16032018002","63a22aae-79c1-4255-91b7-41a2477fc207");



DROP TABLE IF EXISTS `solicitud_facturar`;

CREATE TABLE `solicitud_facturar` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `solicitud_id` varchar(16) DEFAULT NULL,
  `monto` decimal(10,2) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_solicitud_id` (`solicitud_id`),
  CONSTRAINT `fk_solicitud_id` FOREIGN KEY (`solicitud_id`) REFERENCES `solicitud` (`id`) ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=latin1;

INSERT INTO `solicitud_facturar` VALUES("1","PRO01022018002","1.98");
INSERT INTO `solicitud_facturar` VALUES("2","PRO01022018003","7.98");
INSERT INTO `solicitud_facturar` VALUES("3","PAR01022018001","27.50");
INSERT INTO `solicitud_facturar` VALUES("4","PAR01022018001","27.50");
INSERT INTO `solicitud_facturar` VALUES("5","PRO18022018001","8.98");
INSERT INTO `solicitud_facturar` VALUES("6","PAR22022018001","8.42");
INSERT INTO `solicitud_facturar` VALUES("7","ENT16032018001","9.60");
INSERT INTO `solicitud_facturar` VALUES("8","ENT16032018002","9.60");



DROP TABLE IF EXISTS `solicitud_item_examen`;

CREATE TABLE `solicitud_item_examen` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `solicitud_id` varchar(16) DEFAULT NULL,
  `examen_id` int(11) DEFAULT NULL,
  `precio` double(13,2) DEFAULT NULL,
  `estado` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  KEY `FK_solicitud_item_examen_examenes_id` (`examen_id`),
  KEY `FK_solicitud_item_examen_solicitud_id` (`solicitud_id`),
  CONSTRAINT `FK_solicitud_item_examen_examenes_id` FOREIGN KEY (`examen_id`) REFERENCES `examenes` (`id`),
  CONSTRAINT `FK_solicitud_item_examen_solicitud_id` FOREIGN KEY (`solicitud_id`) REFERENCES `solicitud` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=37 DEFAULT CHARSET=latin1 AVG_ROW_LENGTH=780;

INSERT INTO `solicitud_item_examen` VALUES("1","PRO01022018001","5","0.00","3");
INSERT INTO `solicitud_item_examen` VALUES("2","PRO01022018001","6","0.00","3");
INSERT INTO `solicitud_item_examen` VALUES("3","PRO01022018002","5","0.00","3");
INSERT INTO `solicitud_item_examen` VALUES("4","PRO01022018002","6","0.00","3");
INSERT INTO `solicitud_item_examen` VALUES("5","PRO01022018003","5","0.00","3");
INSERT INTO `solicitud_item_examen` VALUES("6","PRO01022018003","6","0.00","3");
INSERT INTO `solicitud_item_examen` VALUES("7","PAR01022018001","5","27.50","3");
INSERT INTO `solicitud_item_examen` VALUES("8","PRO18022018001","5","0.00","3");
INSERT INTO `solicitud_item_examen` VALUES("9","PRO18022018001","6","0.00","3");
INSERT INTO `solicitud_item_examen` VALUES("10","PAR22022018001","13","9.00","3");
INSERT INTO `solicitud_item_examen` VALUES("11","PAR22022018001","12","3.00","3");
INSERT INTO `solicitud_item_examen` VALUES("12","PAR22022018001","11","3.00","3");
INSERT INTO `solicitud_item_examen` VALUES("13","PAR22022018001","7","2.00","3");
INSERT INTO `solicitud_item_examen` VALUES("31","PAR05032018001","4","15.00","3");
INSERT INTO `solicitud_item_examen` VALUES("32","PAR05032018001","14","3.50","3");
INSERT INTO `solicitud_item_examen` VALUES("33","PAR05032018001","16","5.99","3");
INSERT INTO `solicitud_item_examen` VALUES("34","PAR05032018001","18","7.99","3");
INSERT INTO `solicitud_item_examen` VALUES("35","ENT16032018001","4","9.60","3");
INSERT INTO `solicitud_item_examen` VALUES("36","ENT16032018002","4","9.60","3");



DROP TABLE IF EXISTS `solicitud_item_examen_observacion`;

CREATE TABLE `solicitud_item_examen_observacion` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `solicitud_item_examen_id` int(11) NOT NULL,
  `observacion` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `solicitud_item_examen_id` (`solicitud_item_examen_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;




DROP TABLE IF EXISTS `solicitud_monto`;

CREATE TABLE `solicitud_monto` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `solicitud_monto` varchar(16) DEFAULT NULL,
  `monto` double(13,2) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_solicitud_monto_solicitud_id` (`solicitud_monto`),
  CONSTRAINT `FK_solicitud_monto_solicitud_id` FOREIGN KEY (`solicitud_monto`) REFERENCES `solicitud` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1 AVG_ROW_LENGTH=2340;

INSERT INTO `solicitud_monto` VALUES("1","PRO01022018002","7.00");
INSERT INTO `solicitud_monto` VALUES("2","PAR22022018001","8.58");



DROP TABLE IF EXISTS `solicitud_online`;

CREATE TABLE `solicitud_online` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `solicitud_id` varchar(16) DEFAULT NULL,
  `pay_id` varchar(100) DEFAULT NULL,
  `pay_token` varchar(100) DEFAULT NULL,
  `payer_id` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_solicitud_key` (`solicitud_id`),
  CONSTRAINT `fk_solicitud_key` FOREIGN KEY (`solicitud_id`) REFERENCES `solicitud` (`id`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;




DROP TABLE IF EXISTS `solicitud_promocion`;

CREATE TABLE `solicitud_promocion` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `solicitud_id` varchar(16) NOT NULL,
  `promocion_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_promocion` (`promocion_id`),
  KEY `fk_solicitud` (`solicitud_id`),
  CONSTRAINT `FK_solicitud_promocion_solicitud_id` FOREIGN KEY (`solicitud_id`) REFERENCES `solicitud` (`id`),
  CONSTRAINT `fk_promocion` FOREIGN KEY (`promocion_id`) REFERENCES `promociones` (`id`) ON DELETE NO ACTION ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1 AVG_ROW_LENGTH=2730;

INSERT INTO `solicitud_promocion` VALUES("1","PRO01022018001","9");
INSERT INTO `solicitud_promocion` VALUES("2","PRO01022018002","9");
INSERT INTO `solicitud_promocion` VALUES("3","PRO01022018003","9");
INSERT INTO `solicitud_promocion` VALUES("4","PRO18022018001","9");



DROP TABLE IF EXISTS `solicitud_respuesta`;

CREATE TABLE `solicitud_respuesta` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `catalogo_campo_id` int(11) DEFAULT NULL,
  `solicitud_item_examen_id` int(11) DEFAULT NULL,
  `resultado` varchar(255) DEFAULT NULL,
  `seleccion_valor` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_solicitud_item_examen` (`solicitud_item_examen_id`),
  KEY `fk_campos_solicitud` (`catalogo_campo_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

INSERT INTO `solicitud_respuesta` VALUES("1","2","35","555","POSITIVO");
INSERT INTO `solicitud_respuesta` VALUES("2","6","36","100","RESISTENTES");



DROP TABLE IF EXISTS `sucursales`;

CREATE TABLE `sucursales` (
  `id` varchar(50) NOT NULL,
  `nombre_sucursal` varchar(60) NOT NULL,
  `nit_suc` varchar(20) NOT NULL,
  `email_suc` varchar(100) NOT NULL,
  `address_suc` varchar(75) NOT NULL,
  `phone_suc` varchar(8) NOT NULL,
  `status` int(11) NOT NULL DEFAULT '1',
  `updated_at` datetime DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `lat` varchar(15) DEFAULT NULL,
  `lng` varchar(15) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AVG_ROW_LENGTH=8192;

INSERT INTO `sucursales` VALUES("0e95ed37-0480-437c-8606-40b412e71647","Laboratorio Clinico Zacatecoluca","0785-854788-985-7","mail@gmail.com","Zacatecoluca Centro","79088888","1","2017-10-21 21:25:32","2017-04-16 14:01:54","13.642869425664","-88.78841400146");
INSERT INTO `sucursales` VALUES("725880d6-f625-4a48-926e-6fdb2c9be755","Laboratorio Clinico Casa Matriz","0787-010190-101-4","casa.matroz@gmail.com","San Vicente, Centro","99999999","1","2017-10-21 21:25:10","2017-04-16 14:07:29","13.641858089885","-88.78924012184");
INSERT INTO `sucursales` VALUES("e9b8c5c4-6345-475a-97ae-1231907902f5","jsjs","uuieuju","ususj@lallac","00000000acacac","00000000","0","2018-01-14 14:29:40","2018-01-14 14:29:40","13.652784457237","-88.81167411804");



DROP TABLE IF EXISTS `sucursales_puntos_geograficos`;

CREATE TABLE `sucursales_puntos_geograficos` (
  `sucursal_id` varchar(50) DEFAULT NULL,
  `lat` double(50,30) DEFAULT NULL,
  `lng` double(50,30) DEFAULT NULL,
  KEY `fk_sucursal` (`sucursal_id`),
  CONSTRAINT `fk_sucursal` FOREIGN KEY (`sucursal_id`) REFERENCES `sucursales` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `sucursales_puntos_geograficos` VALUES("725880d6-f625-4a48-926e-6fdb2c9be755","13.634048763621770000000000000000","-88.788188695907590000000000000000");
INSERT INTO `sucursales_puntos_geograficos` VALUES("725880d6-f625-4a48-926e-6fdb2c9be755","13.631796626902831000000000000000","-88.788349628448490000000000000000");
INSERT INTO `sucursales_puntos_geograficos` VALUES("725880d6-f625-4a48-926e-6fdb2c9be755","13.632797579206358000000000000000","-88.783339262008670000000000000000");
INSERT INTO `sucursales_puntos_geograficos` VALUES("725880d6-f625-4a48-926e-6fdb2c9be755","13.633881939415927000000000000000","-88.784251213073730000000000000000");
INSERT INTO `sucursales_puntos_geograficos` VALUES("725880d6-f625-4a48-926e-6fdb2c9be755","13.634976721116296000000000000000","-88.788317441940310000000000000000");
INSERT INTO `sucursales_puntos_geograficos` VALUES("725880d6-f625-4a48-926e-6fdb2c9be755","13.634059190130720000000000000000","-88.788167238235470000000000000000");
INSERT INTO `sucursales_puntos_geograficos` VALUES("e9b8c5c4-6345-475a-97ae-1231907902f5","13.757200547853603000000000000000","-88.950703740119930000000000000000");
INSERT INTO `sucursales_puntos_geograficos` VALUES("e9b8c5c4-6345-475a-97ae-1231907902f5","13.755736385851899000000000000000","-88.950279951095580000000000000000");
INSERT INTO `sucursales_puntos_geograficos` VALUES("e9b8c5c4-6345-475a-97ae-1231907902f5","13.755449805028787000000000000000","-88.949126601219180000000000000000");
INSERT INTO `sucursales_puntos_geograficos` VALUES("e9b8c5c4-6345-475a-97ae-1231907902f5","13.756236598811439000000000000000","-88.948069810867310000000000000000");
INSERT INTO `sucursales_puntos_geograficos` VALUES("e9b8c5c4-6345-475a-97ae-1231907902f5","13.756992126775508000000000000000","-88.949099779129030000000000000000");
INSERT INTO `sucursales_puntos_geograficos` VALUES("e9b8c5c4-6345-475a-97ae-1231907902f5","13.757497547569164000000000000000","-88.949990272521970000000000000000");
INSERT INTO `sucursales_puntos_geograficos` VALUES("e9b8c5c4-6345-475a-97ae-1231907902f5","13.757476705496153000000000000000","-88.950001001358030000000000000000");
INSERT INTO `sucursales_puntos_geograficos` VALUES("e9b8c5c4-6345-475a-97ae-1231907902f5","13.757596547390579000000000000000","-88.950312137603760000000000000000");
INSERT INTO `sucursales_puntos_geograficos` VALUES("e9b8c5c4-6345-475a-97ae-1231907902f5","13.757612178937505000000000000000","-88.950827121734620000000000000000");
INSERT INTO `sucursales_puntos_geograficos` VALUES("e9b8c5c4-6345-475a-97ae-1231907902f5","13.757210968902633000000000000000","-88.950698375701900000000000000000");



DROP TABLE IF EXISTS `tipo_catalogo_campo`;

CREATE TABLE `tipo_catalogo_campo` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nombre_tipo_campo` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1 AVG_ROW_LENGTH=5461;

INSERT INTO `tipo_catalogo_campo` VALUES("1","Seleccionables");
INSERT INTO `tipo_catalogo_campo` VALUES("2","Rangos");
INSERT INTO `tipo_catalogo_campo` VALUES("3","Digitables");



DROP TABLE IF EXISTS `usuarios`;

CREATE TABLE `usuarios` (
  `id_user` int(11) NOT NULL AUTO_INCREMENT,
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `password` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `sucursal_id` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `is_admin` int(1) NOT NULL DEFAULT '0',
  `remember_token` text COLLATE utf8_unicode_ci,
  `estado` int(11) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id_user`),
  UNIQUE KEY `users_email_unique` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AVG_ROW_LENGTH=5461;

INSERT INTO `usuarios` VALUES("1","a@gmail.com","$6$admin$Pvh8qetYOf6uoVEDQDa49mSXOfkDh/EeFkrxi3yc0qN/dSTVR5iyFpbwbtgp7bPBjGZQ8Uz/MiZCAPuwjSD0w1","0e95ed37-0480-437c-8606-40b412e71647","1","EdqsNISr1r","1","2016-12-01 03:59:50","2016-12-01 03:59:50");
INSERT INTO `usuarios` VALUES("2","carlos@admin","$6$admin$Pvh8qetYOf6uoVEDQDa49mSXOfkDh/EeFkrxi3yc0qN/dSTVR5iyFpbwbtgp7bPBjGZQ8Uz/MiZCAPuwjSD0w1","0e95ed37-0480-437c-8606-40b412e71647","0","EdqsNISr1r","0","2017-05-07 00:00:00","2017-05-07 00:00:00");
INSERT INTO `usuarios` VALUES("3","david@admin","$6$admin$Pvh8qetYOf6uoVEDQDa49mSXOfkDh/EeFkrxi3yc0qN/dSTVR5iyFpbwbtgp7bPBjGZQ8Uz/MiZCAPuwjSD0w1","725880d6-f625-4a48-926e-6fdb2c9be755","0","o6e2s7vp04","1","2017-05-07 00:00:00","2017-05-07 00:00:00");



DROP TABLE IF EXISTS `usuarios_perfiles`;

CREATE TABLE `usuarios_perfiles` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `usuario_id` int(11) NOT NULL,
  `perfil_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `perfil_id` (`perfil_id`),
  KEY `usuario_id` (`usuario_id`),
  CONSTRAINT `usuarios_perfiles_ibfk_1` FOREIGN KEY (`usuario_id`) REFERENCES `usuarios` (`id_user`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1 AVG_ROW_LENGTH=5461;

INSERT INTO `usuarios_perfiles` VALUES("1","1","1");
INSERT INTO `usuarios_perfiles` VALUES("2","2","2");
INSERT INTO `usuarios_perfiles` VALUES("3","3","2");
